<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FlotasController extends Controller
{
    //
}
