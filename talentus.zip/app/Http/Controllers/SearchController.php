<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Clientes;
use App\Models\Lineas;
use App\Models\SimCard;
use Dflydev\DotAccessData\Data;

class SearchController extends Controller
{
    //
    public function clientes(Request $request)
    {

        $term = $request->get('term');
        $querys = Clientes::where('razon_social', 'LIKE', '%' . $term . '%')->orderBy('id', 'desc')->get();

        $data = [];

        foreach ($querys as $query) {
            $data[] = [
                'data' => $query->id,
                'value' => $query->razon_social,
                'flotas' => $query->flotas,

            ];
        }

        return array("suggestions" => $data);
    }

    public function busqueda(Request $request)
    {

        $query = $request->get('query');
        $querys = Clientes::where('razon_social', 'LIKE', '%' . $query . '%')->get();

        $clientes = [];
        $data = [];

        $data['emptyOptionsMessage'] = 'No hay coincidencias.';
        $data['name'] = 'country';
        $data['placeholder'] = 'Selecciona un cliente';


        foreach ($querys as $query) {

            $clientes[$query->id] = $query->razon_social;
        }

        $data['data'] = $clientes;

        return $data;
    }


    public function sim_card(Request $request)
    {

        $term = $request->get('term');

        $sims = SimCard::where('sim_card', 'LIKE', '%' . $term . '%')->orderBy('id', 'desc')->get();
        //$sim = sim::all();

        $data = [];

        foreach ($sims as $sim) {
            $data[] = [
                'value' => $sim->sim_card,
                'data' => $sim->id,

            ];
        }


        return array("suggestions" => $data);
    }

    public function lineas(Request $request)
    {

        $term = $request->get('term');

        $lineas = Lineas::where('numero', 'LIKE', '%' . $term . '%')->orderBy('id', 'desc')->get();
        //$lineas = Lineas::all();

        $data = [];

        foreach ($lineas as $linea) {

            if ($linea->sim) {
                $sim_card = $linea->sim->sim_card;
            } else {
                $sim_card = null;
            }

            if ($linea->sim) {
                $operador = $linea->sim->operador;
            } else {
                $operador = null;
            }

            $data[] = [
                'value' => $linea->numero,
                'data' => $linea->id,
                'sim_card' => $sim_card,
                'operador' => $operador,
            ];
        }


        return array("suggestions" => $data);
    }
}
