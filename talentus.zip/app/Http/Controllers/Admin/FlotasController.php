<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Flotas;
use Illuminate\Http\Request;

class FlotasController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('admin.vehiculos.flotas.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.vehiculos.flotas.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Flotas  $flotas
     * @return \Illuminate\Http\Response
     */
    public function show(Flotas $flotas)
    {
        return view('admin.vehiculos.flotas.show');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Flotas  $flotas
     * @return \Illuminate\Http\Response
     */
    public function edit(Flotas $flotas)
    {
        return view('admin.vehiculos.flotas.edit');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Flotas  $flotas
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Flotas $flotas)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Flotas  $flotas
     * @return \Illuminate\Http\Response
     */
    public function destroy(Flotas $flotas)
    {
        //
    }
}
