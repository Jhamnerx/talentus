<?php

namespace App\Http\Livewire\Admin\Proveedores;

use Livewire\Component;

class Import extends Component
{
    public function render()
    {
        return view('livewire.admin.proveedores.import');
    }
}
