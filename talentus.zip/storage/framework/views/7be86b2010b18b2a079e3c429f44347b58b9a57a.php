<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(mix('css/style.css')); ?>">
    <!-- Scripts -->
    <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>



</head>

<body class="font-inter antialiased bg-slate-100 text-slate-600" :class="{ 'sidebar-expanded': sidebarExpanded }"
    x-data="{ page: 'dashboard-main', sidebarOpen: false, sidebarExpanded: localStorage.getItem('sidebar-expanded') == 'true' }"
    x-init="$watch('sidebarExpanded', value => localStorage.setItem('sidebar-expanded', value))">

    <script>
        if (localStorage.getItem('sidebar-expanded') == 'true') {
            document.querySelector('body').classList.add('sidebar-expanded');
        } else {
            document.querySelector('body').classList.remove('sidebar-expanded');
        }
    </script>

    <!-- Page wrapper -->
    <div class="flex h-screen overflow-hidden">

        <!-- Sidebar -->
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('sidebar')->html();
} elseif ($_instance->childHasBeenRendered('ntz8nxT')) {
    $componentId = $_instance->getRenderedChildComponentId('ntz8nxT');
    $componentTag = $_instance->getRenderedChildComponentTagName('ntz8nxT');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ntz8nxT');
} else {
    $response = \Livewire\Livewire::mount('sidebar');
    $html = $response->html();
    $_instance->logRenderedChild('ntz8nxT', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        <!-- Content area -->
        <div class="relative flex flex-col flex-1 overflow-y-auto overflow-x-hidden">

            <!-- Site header -->
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('header')->html();
} elseif ($_instance->childHasBeenRendered('ypZwBij')) {
    $componentId = $_instance->getRenderedChildComponentId('ypZwBij');
    $componentTag = $_instance->getRenderedChildComponentTagName('ypZwBij');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ypZwBij');
} else {
    $response = \Livewire\Livewire::mount('header');
    $html = $response->html();
    $_instance->logRenderedChild('ypZwBij', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

            <!-- Code block starts -->
            <div
                class="my-6 lg:my-12 container px-6 mx-auto flex flex-col md:flex-row items-start md:items-center justify-between pb-4 border-b border-gray-300">
                <!-- Add customer button -->
                <a href="<?php echo e(route('admin.categorias.index')); ?>">
                    <button class="btn bg-indigo-500 hover:bg-indigo-600 text-white">
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-arrow-back w-5 h-5"
                            viewBox="0 0 24 24" stroke-width="1.5" stroke="#ffffff" fill="none" stroke-linecap="round"
                            stroke-linejoin="round">
                            <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                            <path d="M9 11l-4 4l4 4m-4 -4h11a4 4 0 0 0 0 -8h-1" />
                        </svg>
                        <span class="hidden xs:block ml-2">Atras</span>
                    </button>
                </a>
                <div>
                    <h4 class="text-2xl font-bold leading-tight text-gray-800 dark:text-gray-100">CREAR CATEGORIA</h4>
                    <ul aria-label="current Status"
                        class="flex flex-col md:flex-row items-start md:items-center text-gray-600 dark:text-gray-400 text-sm mt-3">
                        <li class="flex items-center mr-4">
                            <div class="mr-1">
                                <img class="dark:hidden"
                                    src="https://tuk-cdn.s3.amazonaws.com/can-uploader/simple_with_sub_text_and_border-svg1.svg"
                                    alt="Active">
                                <img class="dark:block hidden"
                                    src="https://tuk-cdn.s3.amazonaws.com/can-uploader/simple_with_sub_text_and_border-svg1dark.svg"
                                    alt="Active">
                            </div>
                            <span>Active</span>
                        </li>

                    </ul>
                </div>
            </div>
            <!-- Code block ends -->


            <div class="mt-10 sm:mt-0">
                <div class="md:grid md:grid-cols-3 md:gap-6">
                    <div class="md:col-span-1">
                        <div class="px-4 sm:px-0">
                            <h3 class="text-lg font-medium leading-6 text-gray-900">Formulario para crear una categoria
                            </h3>
                            <p class="mt-1 text-sm text-gray-600">
                                Rellena los campos obligatorios
                            </p>
                        </div>
                    </div>
                    <div class="mt-5 md:mt-0 md:col-span-2">
                        <form action="">
                            <div class="shadow overflow-hidden sm:rounded-md">
                                <div class="px-4 py-5 bg-white sm:p-6">
                                    <div class="grid grid-cols-6 gap-6">
                                        <div class="col-span-6 sm:col-span-3">
                                            <label class="block text-sm font-medium mb-1" for="placeholder">W/
                                                Placeholder</label>
                                            <input id="placeholder" class="form-input w-full" type="text"
                                                placeholder="Something cool..." />
                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red"><?php echo e($message); ?></span>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="col-span-6 sm:col-span-4">
                                            <label class="block text-sm font-medium mb-1" for="placeholder">W/
                                                Placeholder</label>
                                            <input id="placeholder" class="form-input w-full" type="text"
                                                placeholder="Something cool..." />
                                        </div>

                                    </div>
                                </div>
                                <div class="px-4 py-3 bg-gray-50 text-right sm:px-6">

                                    <button class="btn bg-emerald-500 hover:bg-emerald-600 focus:outline-none focus:ring-2 focus:ring-offset-2
                                focus:ring-emerald-600 text-white">GUARDAR</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>





        </div>

    </div>

</body>

</html><?php /**PATH C:\xampp3\htdocs\talentus\resources\views/admin/categorias/create.blade.php ENDPATH**/ ?>