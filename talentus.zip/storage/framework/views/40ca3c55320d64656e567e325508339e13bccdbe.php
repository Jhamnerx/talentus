
<?php $__env->startSection('ruta', 'certificados-gps'); ?>
<?php $__env->startSection('contenido'); ?>

<!-- Table -->
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.certificados.gps.certificados-gps-index')->html();
} elseif ($_instance->childHasBeenRendered('LdfcAUg')) {
    $componentId = $_instance->getRenderedChildComponentId('LdfcAUg');
    $componentTag = $_instance->getRenderedChildComponentTagName('LdfcAUg');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('LdfcAUg');
} else {
    $response = \Livewire\Livewire::mount('admin.certificados.gps.certificados-gps-index');
    $html = $response->html();
    $_instance->logRenderedChild('LdfcAUg', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('modals'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.certificados.gps.save')->html();
} elseif ($_instance->childHasBeenRendered('aqaayN2')) {
    $componentId = $_instance->getRenderedChildComponentId('aqaayN2');
    $componentTag = $_instance->getRenderedChildComponentTagName('aqaayN2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('aqaayN2');
} else {
    $response = \Livewire\Livewire::mount('admin.certificados.gps.save');
    $html = $response->html();
    $_instance->logRenderedChild('aqaayN2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.certificados.gps.edit')->html();
} elseif ($_instance->childHasBeenRendered('ifcdlih')) {
    $componentId = $_instance->getRenderedChildComponentId('ifcdlih');
    $componentTag = $_instance->getRenderedChildComponentTagName('ifcdlih');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ifcdlih');
} else {
    $response = \Livewire\Livewire::mount('admin.certificados.gps.edit');
    $html = $response->html();
    $_instance->logRenderedChild('ifcdlih', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('js'); ?>
<script>
    window.addEventListener('certificado-edit', event => {
        iziToast.success({
            position: 'topRight',
            title: 'ACTUALIZADO',
            message: 'El Certificado N° '+event.detail.certificado+' Fue Actualizado',
        });

    })
    
</script>

<script>
    window.addEventListener('certificado-save', event => {
        $( document ).ready(function() {
        Swal.fire({
        icon: 'success',
        title: 'Guardado',
        text: 'El certificado de '+event.detail.vehiculo+' Fue Creado',
        showConfirmButton: true,
        confirmButtonText: "Cerrar"

        })
    });
    })
    
</script>

<script>
    // A basic demo function to handle "select all" functionality
        document.addEventListener('alpine:init', () => {
            Alpine.data('handleSelect', () => ({
                selectall: false,
                selectAction() {
                    countEl = document.querySelector('.table-items-action');
                    if (!countEl) return;
                    checkboxes = document.querySelectorAll('input.table-item:checked');
                    document.querySelector('.table-items-count').innerHTML = checkboxes.length;
                    if (checkboxes.length > 0) {
                        countEl.classList.remove('hidden');
                    } else {
                        countEl.classList.add('hidden');
                    }
                },
                toggleAll() {
                    this.selectall = !this.selectall;
                    checkboxes = document.querySelectorAll('input.table-item');
                    [...checkboxes].map((el) => {
                        el.checked = this.selectall;
                    });
                    this.selectAction();
                },
                uncheckParent() {
                    this.selectall = false;
                    document.getElementById('parent-checkbox').checked = false;
                    this.selectAction();
                }
            }))
        })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\talentus\resources\views/admin/certificados/gps/index.blade.php ENDPATH**/ ?>