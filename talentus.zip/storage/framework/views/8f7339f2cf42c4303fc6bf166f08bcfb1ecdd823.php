
<?php $__env->startSection('ruta', 'clientes'); ?>
<?php $__env->startSection('contenido'); ?>

<!-- Table -->
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.clientes.clientes-index')->html();
} elseif ($_instance->childHasBeenRendered('a3opJe9')) {
    $componentId = $_instance->getRenderedChildComponentId('a3opJe9');
    $componentTag = $_instance->getRenderedChildComponentTagName('a3opJe9');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('a3opJe9');
} else {
    $response = \Livewire\Livewire::mount('admin.clientes.clientes-index');
    $html = $response->html();
    $_instance->logRenderedChild('a3opJe9', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php if(session('store')): ?>


<script>
    $( document ).ready(function() {
        Swal.fire({
        icon: 'success',
        title: 'Guardado',
        text: '<?php echo e(session("store")); ?>',
        showConfirmButton: true,
        confirmButtonText: "Cerrar"

        })
    });


</script>

<?php endif; ?>
<?php if(session('export')): ?>


<script>
    $( document ).ready(function() {
        Swal.fire({
        icon: 'success',
        title: 'Exportar',
        text: '<?php echo e(session("export")); ?>',
        showConfirmButton: true,
        confirmButtonText: "Cerrar"

        })
    });


</script>

<?php endif; ?>
<?php if(session('update')): ?>


<script>
    $( document ).ready(function() {
        Swal.fire({
        icon: 'success',
        title: 'Actualizado',
        text: '<?php echo e(session("update")); ?>',
        showConfirmButton: true,
        confirmButtonText: "Cerrar"

        })
    });


</script>

<?php endif; ?>

<?php if(session('delete')): ?>


<script>
    $( document ).ready(function() {
        Swal.fire({
        icon: 'error',
        title: 'Eliminado',
        text: '<?php echo e(session("delete")); ?>',
        showConfirmButton: true,
        confirmButtonText: "Cerrar"

        })
    });


</script>

<?php endif; ?>

<script>
    // A basic demo function to handle "select all" functionality
    document.addEventListener('alpine:init', () => {
        Alpine.data('handleSelect', () => ({
            selectall: false,
            selectAction() {
                countEl = document.querySelector('.table-items-action');
                if (!countEl) return;
                checkboxes = document.querySelectorAll('input.table-item:checked');
                document.querySelector('.table-items-count').innerHTML = checkboxes.length;
                if (checkboxes.length > 0) {
                    countEl.classList.remove('hidden');
                } else {
                    countEl.classList.add('hidden');
                }
            },
            toggleAll() {
                this.selectall = !this.selectall;
                checkboxes = document.querySelectorAll('input.table-item');
                [...checkboxes].map((el) => {
                    el.checked = this.selectall;
                });
                this.selectAction();
            },
            uncheckParent() {
                this.selectall = false;
                document.getElementById('parent-checkbox').checked = false;
                this.selectAction();
            }
        }))
    })    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\talentus\resources\views/admin/clientes/index.blade.php ENDPATH**/ ?>