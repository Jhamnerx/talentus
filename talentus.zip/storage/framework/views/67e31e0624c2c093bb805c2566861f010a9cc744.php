
<?php $__env->startSection('contenido'); ?>

<!-- Table -->
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.ventas-index')->html();
} elseif ($_instance->childHasBeenRendered('jqM2tCK')) {
    $componentId = $_instance->getRenderedChildComponentId('jqM2tCK');
    $componentTag = $_instance->getRenderedChildComponentTagName('jqM2tCK');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('jqM2tCK');
} else {
    $response = \Livewire\Livewire::mount('admin.ventas-index');
    $html = $response->html();
    $_instance->logRenderedChild('jqM2tCK', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    console.log('Hi!'); 

</script>

<script>
    // A basic demo function to handle "select all" functionality
        document.addEventListener('alpine:init', () => {
            Alpine.data('handleSelect', () => ({
                selectall: false,
                selectAction() {
                    countEl = document.querySelector('.table-items-action');
                    if (!countEl) return;
                    checkboxes = document.querySelectorAll('input.table-item:checked');
                    document.querySelector('.table-items-count').innerHTML = checkboxes.length;
                    if (checkboxes.length > 0) {
                        countEl.classList.remove('hidden');
                    } else {
                        countEl.classList.add('hidden');
                    }
                },
                toggleAll() {
                    this.selectall = !this.selectall;
                    checkboxes = document.querySelectorAll('input.table-item');
                    [...checkboxes].map((el) => {
                        el.checked = this.selectall;
                    });
                    this.selectAction();
                },
                uncheckParent() {
                    this.selectall = false;
                    document.getElementById('parent-checkbox').checked = false;
                    this.selectAction();
                }
            }))
        })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\talentus\resources\views/admin/ventas/facturas/index.blade.php ENDPATH**/ ?>