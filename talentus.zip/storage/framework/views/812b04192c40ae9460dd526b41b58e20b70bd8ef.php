<div class="flex items-center mt-2" x-data="{ checkedf<?php echo e($model->id); ?>: <?php echo e($model->fondo ? 'true' : 'false'); ?> }">
    <span class="text-sm mr-3">Fondo: </span>
    <div class="form-switch">
        <input wire:model.lazy="fondo" type="checkbox" id="switch-f<?php echo e($model->id); ?>" class="sr-only"
            x-model="checkedf<?php echo e($model->id); ?>" />
        <label class="bg-slate-400" for="switch-f<?php echo e($model->id); ?>">
            <span class="bg-white shadow-sm" aria-hidden="true"></span>
            <span class="sr-only">Fondo</span>
        </label>
    </div>
    <div class="text-sm text-slate-400 italic ml-2" x-text="checkedf<?php echo e($model->id); ?> ? 'ON' : 'OFF'"></div>
</div><?php /**PATH C:\xampp2\htdocs\talentus\resources\views/livewire/admin/ventas/contratos/status-fondo.blade.php ENDPATH**/ ?>