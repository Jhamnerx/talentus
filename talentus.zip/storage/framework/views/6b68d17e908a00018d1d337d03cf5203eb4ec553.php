<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <?php $__env->startSection('contenido'); ?>

    
    <?php if (isset($component)) { $__componentOriginal64ac2cc0764c9e474bb9142fbb36db2f74dc5e67 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Welcome::class, []); ?>
<?php $component->withName('welcome'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal64ac2cc0764c9e474bb9142fbb36db2f74dc5e67)): ?>
<?php $component = $__componentOriginal64ac2cc0764c9e474bb9142fbb36db2f74dc5e67; ?>
<?php unset($__componentOriginal64ac2cc0764c9e474bb9142fbb36db2f74dc5e67); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalcdc5aea8a19312811a0c130cfbcbc120757801cc = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Cards::class, []); ?>
<?php $component->withName('cards'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcdc5aea8a19312811a0c130cfbcbc120757801cc)): ?>
<?php $component = $__componentOriginalcdc5aea8a19312811a0c130cfbcbc120757801cc; ?>
<?php unset($__componentOriginalcdc5aea8a19312811a0c130cfbcbc120757801cc); ?>
<?php endif; ?>



    <?php $__env->stopSection(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp2\htdocs\talentus\resources\views/index.blade.php ENDPATH**/ ?>