<div class="flex items-center" x-data="{ checkeds<?php echo e($model->id); ?>: <?php echo e($model->sello ? 'true' : 'false'); ?> }">
    <span class="text-sm mr-5">Sello: </span>
    <div class="form-switch">
        <input wire:model.lazy="sello" type="checkbox" id="switch-s<?php echo e($model->id); ?>" class="sr-only"
            x-model="checkeds<?php echo e($model->id); ?>" />
        <label class="bg-slate-400" for="switch-s<?php echo e($model->id); ?>">
            <span class="bg-white shadow-sm" aria-hidden="true"></span>
            <span class="sr-only">Sello</span>
        </label>
    </div>
    <div class="text-sm text-slate-400 italic ml-2" x-text="checkeds<?php echo e($model->id); ?> ? 'ON' : 'OFF'"></div>
</div><?php /**PATH C:\xampp2\htdocs\talentus\resources\views/livewire/admin/certificados/velocimetros/status-sello.blade.php ENDPATH**/ ?>