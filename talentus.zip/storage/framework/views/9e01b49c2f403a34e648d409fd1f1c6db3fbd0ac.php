
<?php $__env->startSection('ruta', 'vehiculos-reportes'); ?>
<?php $__env->startSection('contenido'); ?>

<!-- Table -->

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.vehiculos.reportes.reportes-index')->html();
} elseif ($_instance->childHasBeenRendered('9f6b1pz')) {
    $componentId = $_instance->getRenderedChildComponentId('9f6b1pz');
    $componentTag = $_instance->getRenderedChildComponentTagName('9f6b1pz');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('9f6b1pz');
} else {
    $response = \Livewire\Livewire::mount('admin.vehiculos.reportes.reportes-index');
    $html = $response->html();
    $_instance->logRenderedChild('9f6b1pz', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('modals'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.vehiculos.reportes.show-contactos')->html();
} elseif ($_instance->childHasBeenRendered('z8AEP7g')) {
    $componentId = $_instance->getRenderedChildComponentId('z8AEP7g');
    $componentTag = $_instance->getRenderedChildComponentTagName('z8AEP7g');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('z8AEP7g');
} else {
    $response = \Livewire\Livewire::mount('admin.vehiculos.reportes.show-contactos');
    $html = $response->html();
    $_instance->logRenderedChild('z8AEP7g', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.vehiculos.reportes.save')->html();
} elseif ($_instance->childHasBeenRendered('0hnCYIK')) {
    $componentId = $_instance->getRenderedChildComponentId('0hnCYIK');
    $componentTag = $_instance->getRenderedChildComponentTagName('0hnCYIK');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('0hnCYIK');
} else {
    $response = \Livewire\Livewire::mount('admin.vehiculos.reportes.save');
    $html = $response->html();
    $_instance->logRenderedChild('0hnCYIK', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.vehiculos.reportes.edit')->html();
} elseif ($_instance->childHasBeenRendered('A5zkWLr')) {
    $componentId = $_instance->getRenderedChildComponentId('A5zkWLr');
    $componentTag = $_instance->getRenderedChildComponentTagName('A5zkWLr');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('A5zkWLr');
} else {
    $response = \Livewire\Livewire::mount('admin.vehiculos.reportes.edit');
    $html = $response->html();
    $_instance->logRenderedChild('A5zkWLr', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.vehiculos.reportes.delete')->html();
} elseif ($_instance->childHasBeenRendered('lV78ht8')) {
    $componentId = $_instance->getRenderedChildComponentId('lV78ht8');
    $componentTag = $_instance->getRenderedChildComponentTagName('lV78ht8');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('lV78ht8');
} else {
    $response = \Livewire\Livewire::mount('admin.vehiculos.reportes.delete');
    $html = $response->html();
    $_instance->logRenderedChild('lV78ht8', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.vehiculos.reportes.show-detalle')->html();
} elseif ($_instance->childHasBeenRendered('l3ye0IC')) {
    $componentId = $_instance->getRenderedChildComponentId('l3ye0IC');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3ye0IC');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3ye0IC');
} else {
    $response = \Livewire\Livewire::mount('admin.vehiculos.reportes.show-detalle');
    $html = $response->html();
    $_instance->logRenderedChild('l3ye0IC', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


<?php $__env->stopPush(); ?>



<?php $__env->startSection('js'); ?>
<script>
    window.addEventListener('reporte-edit', event => {
        iziToast.success({
            position: 'topRight',
            title: 'ACTUALIZADO',
            message: 'El Reporte de '+event.detail.vehiculo+' Fue Actualizado',
        });

    })
    
</script>


<script>
    window.addEventListener('detalle-reporte', event => {
        iziToast.success({
            position: 'topRight',
            title: 'DETALLE AGREGADO',
            message: 'Se añadio un detalle al reporte',
        });

    })
    
</script>

<script>
    window.addEventListener('reporte-delete', event => {
        iziToast.error({
            position: 'topRight',
            title: 'ELIMINADO',
            message: 'El Reporte de '+event.detail.vehiculo+' Fue Eliminado',
        });

    })
    
</script>
<script>
    window.addEventListener('reporte-save', event => {
        $( document ).ready(function() {
        Swal.fire({
        icon: 'success',
        title: 'Guardado',
        text: 'El Reporte de '+event.detail.vehiculo+' Fue Creado',
        showConfirmButton: true,
        confirmButtonText: "Cerrar"

        })
    });
    })
    
</script>



<script>
    // A basic demo function to handle "select all" functionality
        document.addEventListener('alpine:init', () => {
            Alpine.data('handleSelect', () => ({
                selectall: false,
                selectAction() {
                    countEl = document.querySelector('.table-items-action');
                    if (!countEl) return;
                    checkboxes = document.querySelectorAll('input.table-item:checked');
                    document.querySelector('.table-items-count').innerHTML = checkboxes.length;
                    if (checkboxes.length > 0) {
                        countEl.classList.remove('hidden');
                    } else {
                        countEl.classList.add('hidden');
                    }
                },
                toggleAll() {
                    this.selectall = !this.selectall;
                    checkboxes = document.querySelectorAll('input.table-item');
                    [...checkboxes].map((el) => {
                        el.checked = this.selectall;
                    });
                    this.selectAction();
                },
                uncheckParent() {
                    this.selectall = false;
                    document.getElementById('parent-checkbox').checked = false;
                    this.selectAction();
                }
            }))
        })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\talentus\resources\views/admin/vehiculos/reportes/index.blade.php ENDPATH**/ ?>