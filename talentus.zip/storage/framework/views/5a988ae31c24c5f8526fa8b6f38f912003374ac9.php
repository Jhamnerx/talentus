<!DOCTYPE html>
<?php $__env->startSection('ruta', 'almacen-guias'); ?>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(mix('css/style.css')); ?>">
    <!-- Scripts -->
    <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>



</head>

<body class="font-inter antialiased bg-slate-100 text-slate-600" :class="{ 'sidebar-expanded': sidebarExpanded }"
    x-data="{ page: 'dashboard-main', sidebarOpen: false, sidebarExpanded: localStorage.getItem('sidebar-expanded') == 'true' }"
    x-init="$watch('sidebarExpanded', value => localStorage.setItem('sidebar-expanded', value))">

    <script>
        if (localStorage.getItem('sidebar-expanded') == 'true') {
            document.querySelector('body').classList.add('sidebar-expanded');
        } else {
            document.querySelector('body').classList.remove('sidebar-expanded');
        }
    </script>

    <!-- Page wrapper -->
    <div class="flex h-screen overflow-hidden">

        <!-- Sidebar -->
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.sidebar')->html();
} elseif ($_instance->childHasBeenRendered('pjUD6Ip')) {
    $componentId = $_instance->getRenderedChildComponentId('pjUD6Ip');
    $componentTag = $_instance->getRenderedChildComponentTagName('pjUD6Ip');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('pjUD6Ip');
} else {
    $response = \Livewire\Livewire::mount('admin.sidebar');
    $html = $response->html();
    $_instance->logRenderedChild('pjUD6Ip', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        <!-- Content area -->
        <div class="relative flex flex-col flex-1 overflow-y-auto overflow-x-hidden">

            <!-- Site header -->
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.header')->html();
} elseif ($_instance->childHasBeenRendered('UFmd7Lh')) {
    $componentId = $_instance->getRenderedChildComponentId('UFmd7Lh');
    $componentTag = $_instance->getRenderedChildComponentTagName('UFmd7Lh');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('UFmd7Lh');
} else {
    $response = \Livewire\Livewire::mount('admin.header');
    $html = $response->html();
    $_instance->logRenderedChild('UFmd7Lh', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

            index


        </div>

    </div>

</body>

</html><?php /**PATH C:\xampp2\htdocs\talentus\resources\views/admin/almacen/guias/index.blade.php ENDPATH**/ ?>