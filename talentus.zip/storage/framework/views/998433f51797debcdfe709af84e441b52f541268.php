<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(mix('css/style.css')); ?>">
    <!-- Scripts -->
    <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>



</head>

<body class="font-inter antialiased bg-slate-100 text-slate-600" :class="{ 'sidebar-expanded': sidebarExpanded }"
    x-data="{ page: 'dashboard-main', sidebarOpen: false, sidebarExpanded: localStorage.getItem('sidebar-expanded') == 'true' }"
    x-init="$watch('sidebarExpanded', value => localStorage.setItem('sidebar-expanded', value))">

    <script>
        if (localStorage.getItem('sidebar-expanded') == 'true') {
            document.querySelector('body').classList.add('sidebar-expanded');
        } else {
            document.querySelector('body').classList.remove('sidebar-expanded');
        }
    </script>

    <!-- Page wrapper -->
    <div class="flex h-screen overflow-hidden">

        <!-- Sidebar -->
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('sidebar')->html();
} elseif ($_instance->childHasBeenRendered('61GmifH')) {
    $componentId = $_instance->getRenderedChildComponentId('61GmifH');
    $componentTag = $_instance->getRenderedChildComponentTagName('61GmifH');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('61GmifH');
} else {
    $response = \Livewire\Livewire::mount('sidebar');
    $html = $response->html();
    $_instance->logRenderedChild('61GmifH', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        <!-- Content area -->
        <div class="relative flex flex-col flex-1 overflow-y-auto overflow-x-hidden">

            <!-- Site header -->
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('header')->html();
} elseif ($_instance->childHasBeenRendered('vVdTnUi')) {
    $componentId = $_instance->getRenderedChildComponentId('vVdTnUi');
    $componentTag = $_instance->getRenderedChildComponentTagName('vVdTnUi');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('vVdTnUi');
} else {
    $response = \Livewire\Livewire::mount('header');
    $html = $response->html();
    $_instance->logRenderedChild('vVdTnUi', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

            <main>
                <div class="px-4 sm:px-6 lg:px-8 py-8 w-full max-w-9xl mx-auto">

                    <!-- Page header -->
                    <div class="sm:flex sm:justify-between sm:items-center mb-8">

                        <!-- Left: Title -->
                        <div class="mb-4 sm:mb-0">
                            <h1 class="text-2xl md:text-3xl text-slate-800 font-bold">Categorias ✨</h1>
                        </div>

                        <!-- Right: Actions -->
                        <div class="grid grid-flow-col sm:auto-cols-max justify-start sm:justify-end gap-2">

                            <!-- Delete button -->
                            <div class="table-items-action hidden">
                                <div class="flex items-center">
                                    <div class="hidden xl:block text-sm italic mr-2 whitespace-nowrap"><span
                                            class="table-items-count"></span>
                                        items Seleccionados</div>
                                    <button
                                        class="btn bg-white border-slate-200 hover:border-slate-300 text-rose-500 hover:text-rose-600">Delete</button>
                                </div>
                            </div>
                            <!-- Search form -->
                            <form class="relative">
                                <label for="action-search" class="sr-only">Search</label>
                                <input id="action-search" class="form-input pl-9 focus:border-slate-300" type="search"
                                    placeholder="Buscar Categoria…" />
                                <button class="absolute inset-0 right-auto group" type="submit" aria-label="Search">
                                    <svg class="w-4 h-4 shrink-0 fill-current text-slate-400 group-hover:text-slate-500 ml-3 mr-2"
                                        viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M7 14c-3.86 0-7-3.14-7-7s3.14-7 7-7 7 3.14 7 7-3.14 7-7 7zM7 2C4.243 2 2 4.243 2 7s2.243 5 5 5 5-2.243 5-5-2.243-5-5-5z" />
                                        <path
                                            d="M15.707 14.293L13.314 11.9a8.019 8.019 0 01-1.414 1.414l2.393 2.393a.997.997 0 001.414 0 .999.999 0 000-1.414z" />
                                    </svg>
                                </button>
                            </form>

                            <!-- Filter button -->
                            <div class="relative inline-flex">
                                <button
                                    class="btn bg-white border-slate-200 hover:border-slate-300 text-slate-500 hover:text-slate-600">
                                    <span class="sr-only">Filtro</span><wbr>
                                    <svg class="w-4 h-4 fill-current" viewBox="0 0 16 16">
                                        <path
                                            d="M9 15H7a1 1 0 010-2h2a1 1 0 010 2zM11 11H5a1 1 0 010-2h6a1 1 0 010 2zM13 7H3a1 1 0 010-2h10a1 1 0 010 2zM15 3H1a1 1 0 010-2h14a1 1 0 010 2z" />
                                    </svg>
                                </button>
                            </div>

                            <!-- Add customer button -->
                            <a href="<?php echo e(route('admin.categorias.create')); ?>">
                                <button class="btn bg-indigo-500 hover:bg-indigo-600 text-white">
                                    <svg class="w-4 h-4 fill-current opacity-50 shrink-0" viewBox="0 0 16 16">
                                        <path
                                            d="M15 7H9V1c0-.6-.4-1-1-1S7 .4 7 1v6H1c-.6 0-1 .4-1 1s.4 1 1 1h6v6c0 .6.4 1 1 1s1-.4 1-1V9h6c.6 0 1-.4 1-1s-.4-1-1-1z" />
                                    </svg>
                                    <span class="hidden xs:block ml-2">Añadir Categoria</span>
                                </button>
                            </a>

                        </div>

                    </div>

                    <!-- Table -->
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.categorias-index')->html();
} elseif ($_instance->childHasBeenRendered('2XH7Z3J')) {
    $componentId = $_instance->getRenderedChildComponentId('2XH7Z3J');
    $componentTag = $_instance->getRenderedChildComponentTagName('2XH7Z3J');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('2XH7Z3J');
} else {
    $response = \Livewire\Livewire::mount('admin.categorias-index');
    $html = $response->html();
    $_instance->logRenderedChild('2XH7Z3J', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                    <!-- Pagination -->
                    <div class="mt-8">
                        <%= require('html-loader!./partials/pagination-classic.html') %>
                    </div>

                </div>
            </main>


        </div>

    </div>

</body>
<script>
    // A basic demo function to handle "select all" functionality
    document.addEventListener('alpine:init', () => {
        Alpine.data('handleSelect', () => ({
            selectall: false,
            selectAction() {
                countEl = document.querySelector('.table-items-action');
                if (!countEl) return;
                checkboxes = document.querySelectorAll('input.table-item:checked');
                document.querySelector('.table-items-count').innerHTML = checkboxes.length;
                if (checkboxes.length > 0) {
                    countEl.classList.remove('hidden');
                } else {
                    countEl.classList.add('hidden');
                }
            },
            toggleAll() {
                this.selectall = !this.selectall;
                checkboxes = document.querySelectorAll('input.table-item');
                [...checkboxes].map((el) => {
                    el.checked = this.selectall;
                });
                this.selectAction();
            },
            uncheckParent() {
                this.selectall = false;
                document.getElementById('parent-checkbox').checked = false;
                this.selectAction();
            }
        }))
    })    
</script>

</html><?php /**PATH C:\xampp3\htdocs\talentus\resources\views/admin/categorias/index.blade.php ENDPATH**/ ?>