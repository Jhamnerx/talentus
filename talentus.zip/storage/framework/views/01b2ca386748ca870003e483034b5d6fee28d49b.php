
<?php $__env->startSection('ruta', 'almacen-dispositivos'); ?>
<?php $__env->startSection('contenido'); ?>

<!-- Table -->
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.dispositivos.modelos-dispositivos-index')->html();
} elseif ($_instance->childHasBeenRendered('tc7bYbu')) {
    $componentId = $_instance->getRenderedChildComponentId('tc7bYbu');
    $componentTag = $_instance->getRenderedChildComponentTagName('tc7bYbu');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('tc7bYbu');
} else {
    $response = \Livewire\Livewire::mount('admin.dispositivos.modelos-dispositivos-index');
    $html = $response->html();
    $_instance->logRenderedChild('tc7bYbu', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('modals'); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.dispositivos.edit-modelo-dispositivo')->html();
} elseif ($_instance->childHasBeenRendered('ZvCgW98')) {
    $componentId = $_instance->getRenderedChildComponentId('ZvCgW98');
    $componentTag = $_instance->getRenderedChildComponentTagName('ZvCgW98');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ZvCgW98');
} else {
    $response = \Livewire\Livewire::mount('admin.dispositivos.edit-modelo-dispositivo');
    $html = $response->html();
    $_instance->logRenderedChild('ZvCgW98', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('js'); ?>
<script>
    console.log('Hi!'); 

</script>

<script>
    // A basic demo function to handle "select all" functionality
    document.addEventListener('alpine:init', () => {
        Alpine.data('handleSelect', () => ({
            selectall: false,
            selectAction() {
                countEl = document.querySelector('.table-items-action');
                if (!countEl) return;
                checkboxes = document.querySelectorAll('input.table-item:checked');
                document.querySelector('.table-items-count').innerHTML = checkboxes.length;
                if (checkboxes.length > 0) {
                    countEl.classList.remove('hidden');
                } else {
                    countEl.classList.add('hidden');
                }
            },
            toggleAll() {
                this.selectall = !this.selectall;
                checkboxes = document.querySelectorAll('input.table-item');
                [...checkboxes].map((el) => {
                    el.checked = this.selectall;
                });
                this.selectAction();
            },
            uncheckParent() {
                this.selectall = false;
                document.getElementById('parent-checkbox').checked = false;
                this.selectAction();
            }
        }))
    })    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\talentus\resources\views/admin/almacen/dispositivos/modelos-index.blade.php ENDPATH**/ ?>