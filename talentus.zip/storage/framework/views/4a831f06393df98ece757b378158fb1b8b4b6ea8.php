<div class="flex items-center" x-data="{ checked: <?php echo e($model->is_active ? 'true' : 'false'); ?> }">
    <div class="form-switch">
        <input role="switch" wire:model.lazy="is_active" type="checkbox" id="switch-e<?php echo e($model->id); ?>" class="sr-only"
            x-model="checked" />
        <label class="bg-slate-400" for="switch-e<?php echo e($model->id); ?>">
            <span class="bg-white shadow-sm" aria-hidden="true"></span>
            <span class="sr-only">Estado</span>
        </label>
    </div>
    <div class="text-sm text-slate-400 italic ml-2" x-text="checked ? 'on' : 'off'">
    </div>
</div><?php /**PATH C:\xampp2\htdocs\talentus\resources\views/livewire/admin/vehiculos/flotas/change-status.blade.php ENDPATH**/ ?>