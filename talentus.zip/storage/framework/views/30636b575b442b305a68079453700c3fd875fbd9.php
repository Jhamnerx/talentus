
<?php $__env->startSection('ruta', 'certificados-actas'); ?>
<?php $__env->startSection('contenido'); ?>

<!-- Table -->
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.certificados.actas.actas-index')->html();
} elseif ($_instance->childHasBeenRendered('oCCrKyJ')) {
    $componentId = $_instance->getRenderedChildComponentId('oCCrKyJ');
    $componentTag = $_instance->getRenderedChildComponentTagName('oCCrKyJ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('oCCrKyJ');
} else {
    $response = \Livewire\Livewire::mount('admin.certificados.actas.actas-index');
    $html = $response->html();
    $_instance->logRenderedChild('oCCrKyJ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('modals'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.certificados.actas.save')->html();
} elseif ($_instance->childHasBeenRendered('EMb9GMo')) {
    $componentId = $_instance->getRenderedChildComponentId('EMb9GMo');
    $componentTag = $_instance->getRenderedChildComponentTagName('EMb9GMo');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('EMb9GMo');
} else {
    $response = \Livewire\Livewire::mount('admin.certificados.actas.save');
    $html = $response->html();
    $_instance->logRenderedChild('EMb9GMo', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.certificados.actas.edit')->html();
} elseif ($_instance->childHasBeenRendered('HU4nX3e')) {
    $componentId = $_instance->getRenderedChildComponentId('HU4nX3e');
    $componentTag = $_instance->getRenderedChildComponentTagName('HU4nX3e');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('HU4nX3e');
} else {
    $response = \Livewire\Livewire::mount('admin.certificados.actas.edit');
    $html = $response->html();
    $_instance->logRenderedChild('HU4nX3e', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('js'); ?>
<script>
    window.addEventListener('acta-edit', event => {
        iziToast.success({
            position: 'topRight',
            title: 'ACTUALIZADO',
            message: 'El Acta N° '+event.detail.acta+' Fue Actualizado',
        });

    })
    
</script>

<script>
    window.addEventListener('acta-save', event => {
        $( document ).ready(function() {
        Swal.fire({
        icon: 'success',
        title: 'Guardado',
        text: 'El Acta de '+event.detail.vehiculo+' Fue Creado',
        showConfirmButton: true,
        confirmButtonText: "Cerrar"

        })
    });
    })
    
</script>



<script>
    // A basic demo function to handle "select all" functionality
        document.addEventListener('alpine:init', () => {
            Alpine.data('handleSelect', () => ({
                selectall: false,
                selectAction() {
                    countEl = document.querySelector('.table-items-action');
                    if (!countEl) return;
                    checkboxes = document.querySelectorAll('input.table-item:checked');
                    document.querySelector('.table-items-count').innerHTML = checkboxes.length;
                    if (checkboxes.length > 0) {
                        countEl.classList.remove('hidden');
                    } else {
                        countEl.classList.add('hidden');
                    }
                },
                toggleAll() {
                    this.selectall = !this.selectall;
                    checkboxes = document.querySelectorAll('input.table-item');
                    [...checkboxes].map((el) => {
                        el.checked = this.selectall;
                    });
                    this.selectAction();
                },
                uncheckParent() {
                    this.selectall = false;
                    document.getElementById('parent-checkbox').checked = false;
                    this.selectAction();
                }
            }))
        })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\talentus\resources\views/admin/certificados/actas/index.blade.php ENDPATH**/ ?>