
<?php $__env->startSection('ruta', 'ventas-presupuestos'); ?>


<?php $__env->startSection('contenido'); ?>


<!-- Code block starts -->

<div
    class="my-4 container px-10 mx-auto flex flex-col md:flex-row items-start md:items-center justify-between pb-4 border-b border-gray-300">
    <!-- Add customer button -->
    <a href="<?php echo e(route('admin.ventas.presupuestos.index')); ?>">
        <button class="btn bg-indigo-500 hover:bg-indigo-600 text-white">
            <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-arrow-back w-5 h-5"
                viewBox="0 0 24 24" stroke-width="1.5" stroke="#ffffff" fill="none" stroke-linecap="round"
                stroke-linejoin="round">
                <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                <path d="M9 11l-4 4l4 4m-4 -4h11a4 4 0 0 0 0 -8h-1" />
            </svg>
            <span class="hidden xs:block ml-2">Atras</span>
        </button>
    </a>
    <div>
        <h4 class="text-2xl font-bold leading-tight text-gray-800 dark:text-gray-100">CREAR PRESUPUESTO</h4>
        <ul aria-label="current Status"
            class="flex flex-col md:flex-row items-start md:items-center text-gray-600 dark:text-gray-400 text-sm mt-3">
            <li class="flex items-center mr-4">
                <div class="mr-1">
                    <img class="dark:hidden"
                        src="https://tuk-cdn.s3.amazonaws.com/can-uploader/simple_with_sub_text_and_border-svg1.svg"
                        alt="Active">
                    <img class="dark:block hidden"
                        src="https://tuk-cdn.s3.amazonaws.com/can-uploader/simple_with_sub_text_and_border-svg1dark.svg"
                        alt="Active">
                </div>
                <span>Active</span>
            </li>

        </ul>
    </div>
</div>
<!-- Code block ends -->

<div class="p-6 shadow overflow-hidden sm:rounded-md">
    <div class="px-4 py-2 bg-gray-50 sm:p-6">
        <?php echo Form::open(['route' => 'admin.ventas.presupuestos.store']); ?>

        <div class="grid grid-cols-12 gap-2">


            <div class="col-span-12 grid grid-cols-12 md:col-span-6 border-dashed lg:border-r-2 pr-4 gap-2">
                
                <div class="col-span-12 mb-5">

                    <label
                        class="flex text-sm not-italic items-center font-medium text-gray-800 whitespace-nowrap justify-between">
                        <div>Cliente <span class="text-sm text-red-500"> * </span></div>
                    </label>

                    <input class="form-input w-full" type="text" name="cliente" id="clienteSearch" />

                </div>
                
                <div class="col-span-12 mb-5">
                    <label
                        class="flex text-sm not-italic items-center font-medium text-gray-800 whitespace-nowrap justify-between">
                        <div>Número de Presupuesto <span class="text-sm text-red-500"> * </span></div>
                    </label>
                    <div class="relative">
                        <input required name="numero_presupuesto" id="numero_presupuesto"
                            class="form-input w-full valid:border-emerald-300
                                                                required:border-rose-300 invalid:border-rose-300 peer pl-12" type="text" />
                        <div class="absolute inset-0 right-auto flex items-center pointer-events-none">
                            <span class="text-sm text-slate-400 font-medium px-3">PRE-</span>
                        </div>
                    </div>
                </div>
                
                <div class="col-span-6 gap-2">
                    <label
                        class="flex text-sm not-italic items-center font-medium text-gray-800 whitespace-nowrap justify-between">
                        <div>Fecha presupuesto <span class="text-sm text-red-500"> * </span></div>
                        <!---->
                        <!---->
                    </label>
                    <div class="relative">
                        <div class="flex absolute inset-y-0 left-0 items-center pl-3 pointer-events-none">
                            <svg class="w-5 h-5 text-gray-500 dark:text-gray-400" fill="currentColor"
                                viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd"
                                    d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z"
                                    clip-rule="evenodd"></path>
                            </svg>
                        </div>
                        <input name="fecha" type="text"
                            class="form-input valid:border-emerald-300
                                                                                                            required:border-rose-300 invalid:border-rose-300 peer fechaPresupuesto inputDate font-base pl-8 py-2 outline-none focus:ring-primary-400 focus:outline-none focus:border-primary-400 block sm:text-sm border-gray-200 rounded-md text-black input w-full"
                            placeholder="Selecciona la fecha">
                    </div>
                </div>
                <!-- ... -->
                
                <div class="col-span-6 gap-2">
                    <label
                        class="flex text-sm not-italic items-center font-medium text-gray-800 whitespace-nowrap justify-between">
                        <div>Fecha de caducidad <span class="text-sm text-red-500" style="display: none;"> *
                            </span>
                        </div>
                        <!---->
                        <!---->
                    </label>
                    <div class="relative">
                        <div class="flex absolute inset-y-0 left-0 items-center pl-3 pointer-events-none">
                            <svg class="w-5 h-5 text-gray-500 dark:text-gray-400" fill="currentColor"
                                viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd"
                                    d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z"
                                    clip-rule="evenodd"></path>
                            </svg>
                        </div>
                        <input name="fecha_caducidad" type="text"
                            class="form-input valid:border-emerald-300
                                                                                                            required:border-rose-300 invalid:border-rose-300 peer inputDate font-base pl-8 py-2 outline-none focus:ring-primary-400 focus:outline-none focus:border-primary-400 block w-full sm:text-sm border-gray-200 rounded-md text-black input dark:focus:border-blue-500"
                            placeholder="Selecciona la fecha">
                    </div>
                </div>

            </div>

            <div class="col-span-12 grid grid-cols-12 md:col-span-6 border-red-600 lg:pl-6">
                
                <div class="col-span-6">
                    <label class="block text-sm font-medium mb-1 text-gray-800">Tipo de Cambio:
                        <span class="text-rose-500" x-text="tipoCambio"></span> </label>
                    <label class="text-gray-800 block text-sm font-medium mb-1" for="moneda">Moneda
                        <span class="text-rose-500">*</span> </label>

                    <select name="divisa" id="moneda" class="form-select" x-model="divisa"
                        @change="changeCurrency($event.target.value)">
                        <option value="PEN">PEN</option>
                        <option value="USD">USD</option>
                    </select>

                    <input x-model="tipoCambio" x-init="tipoCambio = <?php echo e($tipoCambio); ?>" type="hidden"
                        value="<?php echo e($tipoCambio); ?>">



                </div>

                <div class="col-span-12">
                    <label
                        class="flex text-sm not-italic items-center font-medium text-gray-800 whitespace-nowrap justify-between">
                        <div>Nota
                        </div>
                        <!---->
                        <!---->
                    </label>
                    <textarea class="form-input w-full px-4 py-3" name="nota" id="" cols="30" rows="5"
                        placeholder="Ingresar nota (opcional)"></textarea>
                </div>
                <!-- ... -->

            </div>






            <div class="col-span-12 mt-10 pt-4 bg-white shadow-lg rounded-lg px-3">
                

                <table class="table-auto w-full">
                    <!-- Table header -->
                    <thead
                        class="text-xs font-semibold uppercase text-slate-800 bg-white border-t border-b border-slate-200">
                        <tr>
                            <th class="px-2 first:pl-5 last:pr-5 py-3 whitespace-nowrap">
                                <div class="font-semibold text-left">Artículo o Servicio</div>
                            </th>
                            <th class="px-2 first:pl-5 last:pr-5 py-3 whitespace-nowrap">
                                <div class="font-semibold text-left">Cantidad</div>
                            </th>
                            <th class="px-2 first:pl-5 last:pr-5 py-3 whitespace-nowrap">
                                <div class="font-semibold text-left">Precio</div>
                            </th>
                            <th class="px-2 first:pl-5 last:pr-5 py-3 whitespace-nowrap">
                                <div class="font-semibold text-left">Importe</div>
                            </th>
                            <th class="px-2 first:pl-5 last:pr-5 py-3 whitespace-nowrap">
                                <div class="font-semibold text-left">Acciones</div>
                            </th>

                        </tr>
                    </thead>
                    <!-- Table body -->
                    <tbody class="text-sm divide-y divide-slate-200">
                        <!-- Row -->
                        <tr>
                            <td class="px-2 first:pl-5 last:pr-5 py-3 whitespace-nowrap">
                                <textarea name="descripcion" rows="4" class="form-input"
                                    placeholder="Descripción"></textarea>
                            </td>
                            <td class="px-2 first:pl-5 last:pr-5 py-3 whitespace-nowrap">
                                <input type="number" name="cantidad" min="0" value="1" class="form-input"
                                    placeholder="Cantidad">
                            </td>
                            <td class="px-2 first:pl-5 last:pr-5 py-3 whitespace-nowrap">
                                <input type="number" name="precio" class="form-input" placeholder="Importe">
                            </td>
                            <td class="px-2 first:pl-5 last:pr-5 py-3 whitespace-nowrap">

                            </td>
                            <td class="px-2 first:pl-5 last:pr-5 py-3 whitespace-nowrap w-px">
                                <div class="space-x-1">

                                    <button type="button"
                                        onclick="add_item_to_table('undefined','undefined',undefined); return false;"
                                        class="text-white btn bg-cyan-500 hover:text-slate-500 ">
                                        <span class="sr-only">Añadir</span>


                                        <svg class="w-4 h-4 fill-current" xmlns="http://www.w3.org/2000/svg"
                                            viewBox="0 0 24 24">
                                            <g fill="none" class="nc-icon-wrapper">
                                                <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z"
                                                    fill="currentColor"></path>
                                            </g>
                                        </svg>
                                    </button>
                                </div>
                            </td>
                        </tr>


                        
                        <tr>
                            <td class="px-2 first:pl-5 last:pr-5 py-3 whitespace-nowrap">
                                <textarea name="items[1][descripcion]" class="form-input"
                                    rows="5">Instalación de Equipo GPS</textarea>
                            </td>
                            <td class="px-2 first:pl-5 last:pr-5 py-3 whitespace-nowrap">
                                <input type="number" name="cantidad" min="0" value="1" class="form-input"
                                    placeholder="Cantidad">
                            </td>
                            <td class="px-2 first:pl-5 last:pr-5 py-3 whitespace-nowrap">
                                <input type="number" min="0" onblur="calculate_total();" onchange="calculate_total();"
                                    data-quantity="" name="items[1][precio]" value="1" class="form-input">
                            </td>
                            <td class="px-2 first:pl-5 last:pr-5 py-3 whitespace-nowrap">
                                <input type="number" data-toggle="tooltip" title="" onblur="calculate_total();"
                                    onchange="calculate_total();" name="items[1][total]" value="30000.00"
                                    class="form-input"
                                    data-original-title="La tasa en el campo de entrada no está formateada, editar/añadir el artículo y debe seguir siendo no formateado. No intente dar formato manualmente aquí.">
                            </td>
                            <td class="px-2 first:pl-5 last:pr-5 py-3 whitespace-nowrap w-px">
                                <div class="space-x-1">
                                    <button class="text-rose-500 hover:text-rose-600 rounded-full">
                                        <span class="sr-only">Delete</span>
                                        <svg class="w-8 h-8 fill-current" viewBox="0 0 32 32">
                                            <path d="M13 15h2v6h-2zM17 15h2v6h-2z" />
                                            <path
                                                d="M20 9c0-.6-.4-1-1-1h-6c-.6 0-1 .4-1 1v2H8v2h1v10c0 .6.4 1 1 1h12c.6 0 1-.4 1-1V13h1v-2h-4V9zm-6 1h4v1h-4v-1zm7 3v9H11v-9h10z" />
                                        </svg>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
                


                
                <div class="py-2 ml-auto mt-5 w-full sm:w-2/4 lg:w-1/4 mr-2">
                    <div class="flex justify-between mb-3">
                        <div class="text-gray-900 text-right flex-1 font-medium text-sm">Total neto</div>
                        <div class="text-right w-40">
                            <div class="text-gray-800  text-sm"> $30,000.00</div>
                            <input type="hidden" name="total">
                        </div>
                    </div>
                    <div class="flex justify-between mb-4">
                        <div class="text-sm text-gray-600 text-right flex-1">IGV(18%) incl. en Total</div>
                        <div class="text-right w-40">
                            <div class="text-sm text-gray-600" x-html="totalIGV"></div>
                            <input type="hidden" name="impuesto">
                        </div>
                    </div>

                    <div class="py-2 border-t border-b">
                        <div class="flex justify-between">
                            <div class="text-xl text-gray-600 text-right flex-1">Monto Total</div>
                            <div class="text-right w-40">
                                <div class="text-xl text-gray-800 font-bold" x-html="netTotal"></div>
                                <input type="hidden" name="total_venta">
                            </div>
                        </div>
                    </div>
                </div>



            </div>
        </div>
        <div class="px-4 py-3 text-right sm:px-6">
            <?php echo Form::submit('GUARDAR', ['class' => 'btn bg-emerald-500 hover:bg-emerald-600 focus:outline-none
            focus:ring-2 focus:ring-offset-2
            focus:ring-emerald-600 text-white']); ?>


        </div>
        <?php echo Form::close(); ?>



    </div>






</div>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-maskmoney/3.0.2/jquery.maskMoney.min.js"
    integrity="sha512-Rdk63VC+1UYzGSgd3u2iadi0joUrcwX0IWp2rTh6KXFoAmgOjRS99Vynz1lJPT8dLjvo6JZOqpAHJyfCEZ5KoA=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>


<script>
    $("#money").maskMoney();

</script>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\talentus\resources\views/admin/ventas/presupuestos/create.blade.php ENDPATH**/ ?>