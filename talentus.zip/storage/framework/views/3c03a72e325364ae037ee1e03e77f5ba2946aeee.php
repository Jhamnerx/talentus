
<?php $__env->startSection('ruta', 'certificados-velocimetro'); ?>
<?php $__env->startSection('contenido'); ?>

<!-- Table -->

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.certificados.velocimetros.velocimetros-index')->html();
} elseif ($_instance->childHasBeenRendered('4YUbD9U')) {
    $componentId = $_instance->getRenderedChildComponentId('4YUbD9U');
    $componentTag = $_instance->getRenderedChildComponentTagName('4YUbD9U');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('4YUbD9U');
} else {
    $response = \Livewire\Livewire::mount('admin.certificados.velocimetros.velocimetros-index');
    $html = $response->html();
    $_instance->logRenderedChild('4YUbD9U', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('modals'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.certificados.velocimetros.save')->html();
} elseif ($_instance->childHasBeenRendered('Op4Cto6')) {
    $componentId = $_instance->getRenderedChildComponentId('Op4Cto6');
    $componentTag = $_instance->getRenderedChildComponentTagName('Op4Cto6');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Op4Cto6');
} else {
    $response = \Livewire\Livewire::mount('admin.certificados.velocimetros.save');
    $html = $response->html();
    $_instance->logRenderedChild('Op4Cto6', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.certificados.velocimetros.edit')->html();
} elseif ($_instance->childHasBeenRendered('GJEBI2e')) {
    $componentId = $_instance->getRenderedChildComponentId('GJEBI2e');
    $componentTag = $_instance->getRenderedChildComponentTagName('GJEBI2e');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('GJEBI2e');
} else {
    $response = \Livewire\Livewire::mount('admin.certificados.velocimetros.edit');
    $html = $response->html();
    $_instance->logRenderedChild('GJEBI2e', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopPush(); ?>


<?php $__env->startSection('js'); ?>
<script>
    window.addEventListener('certificado-velocimetro-edit', event => {
        iziToast.success({
            position: 'topRight',
            title: 'ACTUALIZADO',
            message: 'El Certificado N° '+event.detail.certificado+' Fue Actualizado',
        });

    })
    
</script>

<script>
    window.addEventListener('certificado-velocimetro-save', event => {
        $( document ).ready(function() {
        Swal.fire({
        icon: 'success',
        title: 'Guardado',
        text: 'El certificado de '+event.detail.vehiculo+' Fue Creado',
        showConfirmButton: true,
        confirmButtonText: "Cerrar"

        })
    });
    })
    
</script>

<script>
    // A basic demo function to handle "select all" functionality
        document.addEventListener('alpine:init', () => {
            Alpine.data('handleSelect', () => ({
                selectall: false,
                selectAction() {
                    countEl = document.querySelector('.table-items-action');
                    if (!countEl) return;
                    checkboxes = document.querySelectorAll('input.table-item:checked');
                    document.querySelector('.table-items-count').innerHTML = checkboxes.length;
                    if (checkboxes.length > 0) {
                        countEl.classList.remove('hidden');
                    } else {
                        countEl.classList.add('hidden');
                    }
                },
                toggleAll() {
                    this.selectall = !this.selectall;
                    checkboxes = document.querySelectorAll('input.table-item');
                    [...checkboxes].map((el) => {
                        el.checked = this.selectall;
                    });
                    this.selectAction();
                },
                uncheckParent() {
                    this.selectall = false;
                    document.getElementById('parent-checkbox').checked = false;
                    this.selectAction();
                }
            }))
        })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\talentus\resources\views/admin/certificados/velocimetros/index.blade.php ENDPATH**/ ?>