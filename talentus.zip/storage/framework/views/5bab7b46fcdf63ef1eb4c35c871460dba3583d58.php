
<?php $__env->startSection('ruta', 'almacen-lineas'); ?>
<?php $__env->startSection('contenido'); ?>

<!-- Table -->
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.lineas.lineas-index')->html();
} elseif ($_instance->childHasBeenRendered('8DW2iCf')) {
    $componentId = $_instance->getRenderedChildComponentId('8DW2iCf');
    $componentTag = $_instance->getRenderedChildComponentTagName('8DW2iCf');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('8DW2iCf');
} else {
    $response = \Livewire\Livewire::mount('admin.lineas.lineas-index');
    $html = $response->html();
    $_instance->logRenderedChild('8DW2iCf', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    console.log('Hi!'); 

</script>

<script>
    // A basic demo function to handle "select all" functionality
    document.addEventListener('alpine:init', () => {
        Alpine.data('handleSelect', () => ({
            selectall: false,
            selectAction() {
                countEl = document.querySelector('.table-items-action');
                if (!countEl) return;
                checkboxes = document.querySelectorAll('input.table-item:checked');
                document.querySelector('.table-items-count').innerHTML = checkboxes.length;
                if (checkboxes.length > 0) {
                    countEl.classList.remove('hidden');
                } else {
                    countEl.classList.add('hidden');
                }
            },
            toggleAll() {
                this.selectall = !this.selectall;
                checkboxes = document.querySelectorAll('input.table-item');
                [...checkboxes].map((el) => {
                    el.checked = this.selectall;
                });
                this.selectAction();
            },
            uncheckParent() {
                this.selectall = false;
                document.getElementById('parent-checkbox').checked = false;
                this.selectAction();
            }
        }))
    })
    

</script>
<?php if(session('store')): ?>


<script>
    $( document ).ready(function() {
        Swal.fire({
        icon: 'success',
        title: 'Guardado',
        text: '<?php echo e(session("store")); ?>',
        showConfirmButton: true,
        confirmButtonText: "Cerrar"

        })
    });


</script>

<?php endif; ?>
<?php if(session('asign')): ?>


<script>
    $( document ).ready(function() {
        Swal.fire({
        icon: 'success',
        title: 'Asignado',
        text: '<?php echo e(session("asign")); ?>',
        showConfirmButton: true,
        confirmButtonText: "Cerrar"

        })
    });


</script>

<?php endif; ?>
<?php if(session('update')): ?>


<script>
    $( document ).ready(function() {
        Swal.fire({
        icon: 'success',
        title: 'Actualizado',
        text: '<?php echo e(session("update")); ?>',
        showConfirmButton: true,
        confirmButtonText: "Cerrar"

        })
    });


</script>

<?php endif; ?>

<?php if(session('delete')): ?>


<script>
    $( document ).ready(function() {
        Swal.fire({
        icon: 'error',
        title: 'Eliminado',
        text: '<?php echo e(session("delete")); ?>',
        showConfirmButton: true,
        confirmButtonText: "Cerrar"

        })
    });


</script>

<?php endif; ?>

<?php if(session('unasign')): ?>


<script>
    $( document ).ready(function() {
        Swal.fire({
        icon: 'error',
        title: 'Eliminado',
        text: '<?php echo e(session("unasign")); ?>',
        showConfirmButton: true,
        confirmButtonText: "Cerrar"

        })
    });


</script>

<?php endif; ?>
<?php if(session()->has('import')): ?>


<script>
    $( document ).ready(function() {
        Swal.fire({
        icon: 'success',
        title: 'Importar',
        text: '<?php echo e(session("import")); ?>',
        showConfirmButton: true,
        confirmButtonText: "Cerrar"

        })
    });


</script>

<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp2\htdocs\talentus\resources\views/admin/almacen/lineas/index.blade.php ENDPATH**/ ?>