require('./bootstrap');
require('./main');
require('./utils');
require('./slider');

import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();
