<x-app-layout>

    @section('contenido')
    CONSULTA VEHICULOS
    @endsection

</x-app-layout>