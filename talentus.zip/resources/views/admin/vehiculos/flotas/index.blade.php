@extends('layouts.admin')
@section('contenido')

<!-- Table -->
@livewire('admin.vehiculos.flotas.flotas-index')

@stop

@section('js')
<script>
    // A basic demo function to handle "select all" functionality
    document.addEventListener('alpine:init', () => {
        Alpine.data('handleSelect', () => ({
            selectall: false,
            selectAction() {
                countEl = document.querySelector('.table-items-action');
                if (!countEl) return;
                checkboxes = document.querySelectorAll('input.table-item:checked');
                document.querySelector('.table-items-count').innerHTML = checkboxes.length;
                if (checkboxes.length > 0) {
                    countEl.classList.remove('hidden');
                } else {
                    countEl.classList.add('hidden');
                }
            },
            toggleAll() {
                this.selectall = !this.selectall;
                checkboxes = document.querySelectorAll('input.table-item');
                [...checkboxes].map((el) => {
                    el.checked = this.selectall;
                });
                this.selectAction();
            },
            uncheckParent() {
                this.selectall = false;
                document.getElementById('parent-checkbox').checked = false;
                this.selectAction();
            }
        }))
    })    
</script>
<script>
    $('#cliente').devbridgeAutocomplete({
            // serviceUrl: '/autosuggest/service/url',
            lookup: function (query, done) {

                // Do Ajax call or lookup locally, when done,
                // call the callback and pass your results:
                $.ajax({
                    url: "{{route('search.clientes')}}",
                    dataType: 'json',
                    data: {
                        term: query
                    },
                    success: function(data){

                        done(data);
                        //console.log(data);
                    }
                })

            },
            // serviceUrl: "{{route('search.lineas')}}",
            // type: 'GET',
            // dataType: 'json',

            minChars: 2,
            autoSelectFirst: false,
            deferRequestBy: 5,
            onSelect: function(suggestion) {

               // $('#numero').val(suggestion.data);
                //console.log(suggestion);
                //$('#clientes_id').val(suggestion.data);
               Livewire.emit('ChangeCliente', suggestion.data, suggestion.value);

            },
            onHint: function (hint) {
               //$('#numero').val(hint);
                //console.log(hint);


            }

        });

</script>

@endsection