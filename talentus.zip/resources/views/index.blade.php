<x-app-layout>

    @section('contenido')

    {{-- componente de bienvenida --}}
    <x-welcome />

    <x-cards />



    @endsection

</x-app-layout>